#include "filesystem.h"

namespace filesystem {
constexpr char path::preferred_separator;
}
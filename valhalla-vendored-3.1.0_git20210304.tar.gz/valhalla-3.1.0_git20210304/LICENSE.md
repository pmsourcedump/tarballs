For license information see [here](COPYING)
